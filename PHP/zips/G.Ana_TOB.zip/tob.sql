-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 06-11-2024 a las 11:13:50
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `tob`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `state` tinyint(1) DEFAULT 0,
  `date` datetime DEFAULT NULL,
  `total_price` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `orders`
--

INSERT INTO `orders` (`id`, `id_user`, `state`, `date`, `total_price`) VALUES
(1, 1, 0, '0000-00-00 00:00:00', 0),
(2, 2, 0, '0000-00-00 00:00:00', 0),
(3, 14, 1, '0000-00-00 00:00:00', 0),
(7, 14, 1, NULL, 0),
(8, 14, 1, '2024-11-05 18:06:39', 0),
(9, 14, 1, '2024-11-05 18:11:51', 0),
(10, 14, 1, '2024-11-05 18:53:04', 0),
(11, 14, 1, '2024-11-05 19:03:10', 100),
(12, 14, 1, '2024-11-05 19:04:16', 200),
(13, 14, 1, '2024-11-05 19:06:18', 100),
(14, 14, 1, '2024-11-05 19:07:37', 0),
(15, 14, 1, '2024-11-05 19:16:54', 0),
(16, 14, 1, '2024-11-05 19:17:57', 0),
(17, 14, 1, '2024-11-05 19:19:40', 200),
(18, 14, 1, '2024-11-05 19:21:41', 30),
(19, 14, 1, '2024-11-05 19:21:56', 0),
(20, 14, 1, '2024-11-05 19:24:19', 1600),
(21, 14, 1, '2024-11-06 10:16:04', 50);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `order_line`
--

CREATE TABLE `order_line` (
  `id_order` int(11) NOT NULL,
  `id_product` int(11) NOT NULL,
  `amount` int(11) NOT NULL,
  `line_price` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `order_line`
--

INSERT INTO `order_line` (`id_order`, `id_product`, `amount`, `line_price`) VALUES
(3, 1, 5, 4000),
(3, 3, 3, 90),
(3, 4, 9, 9000),
(3, 41, 2, 70),
(3, 49, 14, 420),
(7, 41, 3, 105),
(8, 7, 1, 600),
(8, 39, 2, 100),
(9, 47, 8, 160),
(10, 44, 1, 90),
(11, 50, 1, 100),
(12, 50, 2, 200),
(13, 50, 1, 100),
(17, 50, 2, 200),
(18, 49, 1, 30),
(20, 1, 2, 1600),
(21, 38, 2, 50);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `name` varchar(20) NOT NULL,
  `img` varchar(100) NOT NULL,
  `price` double NOT NULL,
  `description` text NOT NULL,
  `stock` int(11) NOT NULL,
  `id_user` int(11) NOT NULL DEFAULT 2
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `products`
--

INSERT INTO `products` (`id`, `name`, `img`, `price`, `description`, `stock`, `id_user`) VALUES
(1, 'Apple iPhone 13', 'iphone13.jpg', 799.99, 'Latest model of iPhone with 128GB storage and A15 Bionic chip.', 43, 1),
(2, 'Samsung Galaxy S21', 'galaxy_s21.jpg', 699.99, 'Samsung flagship smartphone with 5G connectivity and 128GB storage.', 70, 2),
(3, 'Sony WH-1000XM4', 'sony_wh1000xm4.jpg', 349.99, 'Noise-cancelling wireless headphones with up to 30 hours of battery life.', 117, 2),
(4, 'Apple MacBook Air M1', 'macbook_air_m1.jpg', 999.99, 'Apple MacBook Air with M1 chip, 8GB RAM, and 256GB SSD.', 21, 2),
(5, 'Dell XPS 13', 'dell_xps_13.jpg', 1199.99, '13-inch laptop with InfinityEdge display, Intel i7 processor, and 512GB SSD.', 40, 2),
(6, 'Nintendo Switch', 'nintendo_switch.jpg', 299.99, 'Hybrid gaming console with detachable controllers and 32GB internal storage.', 200, 2),
(7, 'Google Pixel 6', 'google_pixel_6.jpg', 599.99, 'Google Pixel 6 smartphone with Tensor chip and 128GB storage.', 79, 2),
(8, 'Sony PlayStation 5', 'ps5.jpg', 499.99, 'Next-gen gaming console with 825GB SSD and ray-tracing support.', 25, 2),
(9, 'Apple AirPods Pro', 'airpods_pro.jpg', 249.99, 'Wireless in-ear headphones with active noise cancellation and wireless charging.', 150, 2),
(10, 'Fitbit Charge 5', 'fitbit_charge_5.jpg', 179.99, 'Advanced fitness and health tracker with GPS, stress management, and sleep tracking.', 100, 2),
(35, 'Producto 1', 'defecto.jpg', 10, 'Descripción del producto 1', 50, 1),
(36, 'Producto 2', 'defecto.jpg', 20, 'Descripción del producto 2', 30, 2),
(37, 'Producto 3', 'defecto.jpg', 15, 'Descripción del producto 3', 20, 1),
(38, 'Producto 4', 'defecto.jpg', 25, 'Descripción del producto 4', 38, 2),
(39, 'Producto 5', 'defecto.jpg', 50, 'Descripción del producto 5', 13, 1),
(40, 'Producto 6', 'defecto.jpg', 60, 'Descripción del producto 6', 25, 2),
(41, 'Producto 7', 'defecto.jpg', 35, 'Descripción del producto 7', 40, 1),
(42, 'Producto 8', 'defecto.jpg', 80, 'Descripción del producto 8', 10, 2),
(43, 'Producto 9', 'defecto.jpg', 40, 'Descripción del producto 9', 30, 1),
(44, 'Producto 10', 'defecto.jpg', 90, 'Descripción del producto 10', 49, 2),
(45, 'Producto 11', 'defecto.jpg', 5, 'Descripción del producto 11', 100, 1),
(46, 'Producto 12', 'defecto.jpg', 55, 'Descripción del producto 12', 60, 2),
(47, 'Producto 13', 'defecto.jpg', 20, 'Descripción del producto 13', 27, 1),
(48, 'Producto 14', 'defecto.jpg', 75, 'Descripción del producto 14', 22, 2),
(49, 'Producto 15', 'defecto.jpg', 30, 'Descripción del producto 15', 25, 1),
(50, 'Producto 16', 'defecto.jpg', 100, 'Descripción del producto 16', -1, 2);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL,
  `isAdmin` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `isAdmin`) VALUES
(1, 'ana', 'ana', 1),
(2, 'admin', 'admin', 1),
(14, 'ana2', 'ana2', 0),
(17, 'user1', 'password1', 0),
(18, 'user2', 'password2', 1),
(19, 'user3', 'password3', 0),
(20, 'user4', 'password4', 1),
(21, 'user5', 'password5', 0),
(22, 'user6', 'password6', 1),
(23, 'user7', 'password7', 0),
(24, 'user8', 'password8', 1),
(25, 'user9', 'password9', 0),
(26, 'user10', 'password10', 1);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_user` (`id_user`);

--
-- Indices de la tabla `order_line`
--
ALTER TABLE `order_line`
  ADD PRIMARY KEY (`id_order`,`id_product`),
  ADD KEY `id_product` (`id_product`);

--
-- Indices de la tabla `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_user_product` (`id_user`);

--
-- Indices de la tabla `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT de la tabla `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=56;

--
-- AUTO_INCREMENT de la tabla `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`id_user`) REFERENCES `users` (`id`);

--
-- Filtros para la tabla `order_line`
--
ALTER TABLE `order_line`
  ADD CONSTRAINT `fk_order` FOREIGN KEY (`id_order`) REFERENCES `orders` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `order_line_ibfk_1` FOREIGN KEY (`id_order`) REFERENCES `orders` (`id`),
  ADD CONSTRAINT `order_line_ibfk_2` FOREIGN KEY (`id_product`) REFERENCES `products` (`id`);

--
-- Filtros para la tabla `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `fk_user_product` FOREIGN KEY (`id_user`) REFERENCES `users` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
