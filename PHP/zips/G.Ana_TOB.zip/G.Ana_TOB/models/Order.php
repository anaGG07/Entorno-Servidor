<?php

class Order
{
    private $id;
    private $id_user;
    private $state;
    private $date;
    private $total_price; // SUM(LP.price)
    private $orderLines = [];

    public function __construct($id, $id_user, $state, $date, $orderLines = [], $total_price = 0)
    {
        $this->id = $id;
        $this->id_user = $id_user;
        $this->state = $state;
        $this->date = $date;
        $this->orderLines = $orderLines;
        $this->total_price = $total_price;
    }

    // GETTERS

    public function getId()
    {
        return $this->id;
    }

    public function getIdUser()
    {
        return $this->id_user;
    }

    public function getState()
    {
        return $this->state;
    }

    public function getDate()
    {
        return $this->date;
    }

    public function getTotalPrice()
    {
        return $this->total_price;
    }

    public function getOrderLines()
    {
        return $this->orderLines;
    }

    // SETTERS

    public function setState($state)
    {
        $this->state = $state;
    }

    public function setOrderLines($orderLines)
    {
        $this->orderLines = $orderLines;
    }

    public function setTotalPrice($total_price){
        $this->total_price = $total_price;
    }

    public function __toString()
    {
        return "Order ID: $this->id, User ID: $this->id_user, State: $this->state, Date: $this->date, Total Price: $this->total_price";
    }
}
