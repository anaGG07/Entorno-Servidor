-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 01-12-2024 a las 18:31:34
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `agoraforum`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `post`
--

CREATE TABLE `post` (
  `id` bigint(20) NOT NULL,
  `id_user` bigint(20) NOT NULL,
  `id_post` bigint(20) DEFAULT NULL,
  `id_theme` bigint(20) DEFAULT 0,
  `title` varchar(255) DEFAULT NULL,
  `text` text NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp(),
  `scope` tinyint(4) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `post`
--

INSERT INTO `post` (`id`, `id_user`, `id_post`, `id_theme`, `title`, `text`, `image`, `timestamp`, `scope`) VALUES
(1, 2, NULL, 1, '¿Cómo será el futuro de la inteligencia artificial?', '¿Qué opinan sobre los avances de la IA en el futuro cercano?', NULL, '2024-11-28 09:00:00', 0),
(2, 3, NULL, 5, '¿Qué países recomiendan visitar en Europa?', 'Estoy planeando un viaje y me gustaría escuchar sugerencias.', 'https://picsum.photos/200/300', '2024-11-28 09:30:00', 1),
(3, 4, NULL, 10, '¿Cuál es tu libro favorito?', 'Busco recomendaciones de libros que realmente te hayan impactado.', NULL, '2024-11-28 10:00:00', 0),
(4, 5, NULL, 15, '¿Qué piensan sobre el cambio climático?', '¿Creen que estamos a tiempo de revertir el daño ambiental?', NULL, '2024-11-28 10:30:00', 0),
(5, 6, NULL, 20, '¿Cuál es el mejor auto eléctrico?', 'Quiero comprar un auto eléctrico y busco recomendaciones.', NULL, '2024-11-28 11:00:00', 0),
(6, 7, 1, 1, NULL, 'Pienso que la IA tendrá un impacto positivo si se regula correctamente.', NULL, '2024-11-28 11:30:00', 0),
(7, 8, 1, 1, NULL, 'Creo que la IA revolucionará la educación, especialmente en países en desarrollo.', NULL, '2024-11-28 11:45:00', 0),
(8, 9, 2, 5, NULL, 'Francia es un destino increíble para disfrutar de cultura y gastronomía.', 'https://picsum.photos/200/300', '2024-11-28 12:00:00', 0),
(9, 10, 3, 10, NULL, 'Mi libro favorito es \"Cien años de soledad\", es una obra maestra.', NULL, '2024-11-28 12:30:00', 0),
(10, 11, 4, 15, NULL, 'El cambio climático es un tema serio, necesitamos más acción inmediata.', NULL, '2024-11-28 13:00:00', 0),
(11, 12, 5, 20, NULL, 'Tesla es una gran opción por su tecnología avanzada y autonomía.', NULL, '2024-11-28 13:30:00', 0),
(12, 6, 7, 1, NULL, 'Totalmente de acuerdo, la regulación es clave para evitar abusos.', NULL, '2024-11-28 14:00:00', 0),
(13, 7, 8, 1, NULL, 'La educación personalizada será revolucionaria gracias a la IA.', NULL, '2024-11-28 14:15:00', 0),
(14, 8, 9, 5, NULL, 'Además de Francia, Italia es un destino espectacular por su historia.', 'https://picsum.photos/200/300', '2024-11-28 14:30:00', 0),
(15, 9, 10, 10, NULL, 'También recomiendo \"1984\" de George Orwell, un clásico distópico.', NULL, '2024-11-28 14:45:00', 0),
(16, 10, 11, 15, NULL, 'Es importante reducir las emisiones y apostar por energías renovables.', NULL, '2024-11-28 15:00:00', 0),
(21, 11, 6, 1, NULL, 'Exacto, y también necesitamos educación sobre IA para el público en general.', NULL, '2024-11-28 15:30:00', 0),
(22, 12, 8, 5, NULL, 'Italia tiene una cultura impresionante, Roma y Venecia son imperdibles.', 'https://picsum.photos/200/300', '2024-11-28 16:00:00', 0),
(23, 13, 9, 10, NULL, 'Gracias por la recomendación, añadiré \"1984\" a mi lista de lectura.', NULL, '2024-11-28 16:30:00', 0),
(24, 11, 10, 15, NULL, 'La transición energética es crucial para combatir el cambio climático.', NULL, '2024-11-28 17:00:00', 0),
(25, 10, 11, 1, NULL, 'Sin duda, la educación es clave para un futuro mejor con IA.', NULL, '2024-11-28 17:30:00', 0),
(26, 8, 12, 5, NULL, 'Gracias por las sugerencias, ¡ya estoy planeando mi itinerario!', 'https://picsum.photos/200/300', '2024-11-28 18:00:00', 0),
(27, 7, 13, 10, NULL, 'Espero que disfrutes \"1984\", es una obra que da mucho para reflexionar.', NULL, '2024-11-28 18:30:00', 0),
(28, 5, 14, 15, NULL, 'Es un desafío global, pero con esfuerzos conjuntos, podemos lograrlo.', NULL, '2024-11-28 19:00:00', 0),
(29, 1, NULL, 1, '¿Android o Apple?', '¿Es mejor que me compre un iPhone o un Android?', NULL, '2024-11-30 16:02:13', 0),
(30, 2, 1, 1, '', 'Da miedo!', '', '0000-00-00 00:00:00', 0),
(31, 2, 30, 1, '', 'Que va!', '', '0000-00-00 00:00:00', 0),
(32, 2, 31, 1, '', 'SISI', '', '2024-11-30 18:43:17', 0),
(33, 2, 31, 1, '', 'totalmente de acuerdo', '', '2024-11-30 18:43:38', 0),
(34, 2, 30, 1, '', 'A mi no me da miedo', '', '2024-11-30 18:43:57', 0),
(41, 2, NULL, 2, 'voy a viajar', '¿Me recomendais destinos para navidad?', NULL, '2024-12-01 16:11:27', 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `theme`
--

CREATE TABLE `theme` (
  `id` bigint(20) NOT NULL,
  `title` varchar(50) NOT NULL,
  `description` varchar(255) NOT NULL,
  `icon` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `theme`
--

INSERT INTO `theme` (`id`, `title`, `description`, `icon`) VALUES
(0, 'Varios/Otros', 'Categoría general para temas diversos o no clasificados', 'https://picsum.photos/30/30'),
(1, 'Tecnología', 'Discute temas relacionados con tecnología e innovación', 'https://picsum.photos/30/30'),
(2, 'Viajes', 'Comparte experiencias y consejos sobre viajes', 'https://picsum.photos/30/30'),
(3, 'Cine', 'Habla de tus películas y series favoritas', 'https://picsum.photos/30/30'),
(4, 'Música', 'Comparte tus canciones, artistas y géneros favoritos', 'https://picsum.photos/30/30'),
(5, 'Deportes', 'Habla sobre deportes y eventos deportivos', 'https://picsum.photos/30/30'),
(6, 'Videojuegos', 'Discute los últimos lanzamientos y tus juegos favoritos', 'https://picsum.photos/30/30'),
(7, 'Salud y Bienestar', 'Consejos para una vida saludable y equilibrada', 'https://picsum.photos/30/30'),
(8, 'Cocina', 'Recetas, consejos y trucos de cocina para todos', 'https://picsum.photos/30/30'),
(9, 'Libros', 'Recomienda y discute libros y autores', 'https://picsum.photos/30/30'),
(10, 'Arte', 'Explora temas relacionados con pintura, escultura y diseño', 'https://picsum.photos/30/30'),
(11, 'Educación', 'Comparte recursos y experiencias de aprendizaje', 'https://picsum.photos/30/30'),
(12, 'Ciencia', 'Discute avances científicos y descubrimientos interesantes', 'https://picsum.photos/30/30'),
(13, 'Historia', 'Habla sobre eventos históricos y su impacto en el presente', 'https://picsum.photos/30/30'),
(14, 'Fotografía', 'Comparte tus fotos y consejos para mejorar tus habilidades', 'https://picsum.photos/30/30'),
(15, 'Moda', 'Tendencias, consejos y discusiones sobre el mundo de la moda', 'https://picsum.photos/30/30'),
(16, 'Animales', 'Comparte experiencias y fotos de tus mascotas o animales favoritos', 'https://picsum.photos/30/30'),
(17, 'Medio Ambiente', 'Habla sobre sostenibilidad y cuidado del planeta', 'https://picsum.photos/30/30'),
(18, 'Tecnología Espacial', 'Discute temas relacionados con exploración espacial y astronomía', 'https://picsum.photos/30/30'),
(19, 'Finanzas', 'Consejos y discusiones sobre manejo de dinero e inversiones', 'https://picsum.photos/30/30'),
(20, 'Automóviles', 'Habla sobre coches, motos y el mundo del motor', 'https://picsum.photos/30/30'),
(21, 'Programación', 'Comparte conocimiento y resuelve problemas de código', 'https://picsum.photos/30/30'),
(22, 'Relaciones y Familia', 'Comparte consejos y experiencias sobre relaciones personales', 'https://picsum.photos/30/30'),
(23, 'Jardinería', 'Consejos y trucos para cultivar plantas y cuidar jardines', 'https://picsum.photos/30/30');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `user`
--

CREATE TABLE `user` (
  `id` bigint(20) NOT NULL,
  `username` varchar(20) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `avatar` varchar(255) DEFAULT NULL,
  `bio` varchar(255) DEFAULT NULL,
  `state` smallint(6) DEFAULT 0,
  `isAdmin` tinyint(4) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `user`
--

INSERT INTO `user` (`id`, `username`, `email`, `password`, `avatar`, `bio`, `state`, `isAdmin`) VALUES
(1, 'admin', 'admin@example.com', 'admin', 'https://picsum.photos/200/300', 'Aventurero de la vida', 1, 1),
(2, 'ana', 'ana@example.com', 'ana', 'https://picsum.photos/200/300', 'Amante de las mariposas', 1, 0),
(3, 'nik123', 'nik@example.com', 'nik123', 'https://picsum.photos/200/300', 'Explorador de la tormenta', -1, 0),
(4, 'johndoe', 'john@example.com', 'password123', 'https://picsum.photos/200/300', 'Fanático de la tecnología', 1, 0),
(5, 'janedoe', 'jane@example.com', 'password456', 'https://picsum.photos/200/300', 'Entusiasta del arte y la fotografía', 1, 0),
(6, 'gamemaster', 'game@example.com', 'playhard', 'https://picsum.photos/200/300', 'Amante de los videojuegos', 1, 0),
(7, 'chef123', 'chef@example.com', 'cookit', 'https://picsum.photos/200/300', 'Explorador de sabores', 1, 0),
(8, 'fitguru', 'fit@example.com', 'fitnesspro', 'https://picsum.photos/200/300', 'Apasionado por el bienestar y la salud', 1, 0),
(9, 'booklover', 'book@example.com', 'readmore', 'https://picsum.photos/200/300', 'Coleccionista de historias y aventuras', 1, 0),
(10, 'spacefan', 'space@example.com', 'tothemoon', 'https://picsum.photos/200/300', 'Admirador del cosmos y la ciencia', -1, 0),
(11, 'naturelover', 'nature@example.com', 'greenthumb', 'https://picsum.photos/200/300', 'Cuidador de la naturaleza', 1, 0),
(12, 'carfanatic', 'car@example.com', 'vroomvroom', 'https://picsum.photos/200/300', 'Apasionado por los coches y las motos', 0, 0),
(13, 'programmer', 'code@example.com', 'debuglife', 'https://picsum.photos/200/300', 'Creador de mundos digitales', 1, 0);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `post`
--
ALTER TABLE `post`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_user_post` (`id_user`),
  ADD KEY `fk_answer_post` (`id_post`),
  ADD KEY `fk_theme_post` (`id_theme`);

--
-- Indices de la tabla `theme`
--
ALTER TABLE `theme`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `title` (`title`);

--
-- Indices de la tabla `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `post`
--
ALTER TABLE `post`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=42;

--
-- AUTO_INCREMENT de la tabla `theme`
--
ALTER TABLE `theme`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT de la tabla `user`
--
ALTER TABLE `user`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `post`
--
ALTER TABLE `post`
  ADD CONSTRAINT `fk_answer_post` FOREIGN KEY (`id_post`) REFERENCES `post` (`id`),
  ADD CONSTRAINT `fk_theme_post` FOREIGN KEY (`id_theme`) REFERENCES `theme` (`id`),
  ADD CONSTRAINT `fk_user_post` FOREIGN KEY (`id_user`) REFERENCES `user` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
