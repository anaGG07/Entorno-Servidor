<?php
  if($_POST['value'] && $_POST['value'] = 'add'){
    require_once('views\question\FormQuestion.phtml');
  }
?>