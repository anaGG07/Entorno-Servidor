<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <script src="./public/js/script.js" defer></script>

    <link rel="stylesheet" href="public/css/style.css">
     <link rel="stylesheet" href="public/css/postStyle.css">
    <link rel="stylesheet" href="public/css/generalStyle.css">
    <link rel="stylesheet" href="public/css/postDetail.css">
    <link rel="stylesheet" href="public/css/userProfile.css"> 
    <link rel="stylesheet" href="public/css/LandingPage.css">
    <link rel="stylesheet" href="public/css/login.css">
    

    <title>Foro</title>
</head>

<body>

    <body>
        <?php
        require_once("db.php");
        
        require_once("controllers/MainController.php");
        
        ?>
    </body>
</body>

</html>