<?php
  if ($_POST['action'] === 'search') {
    require_once('views\songs\SearchSongView.phtml');
}
?>